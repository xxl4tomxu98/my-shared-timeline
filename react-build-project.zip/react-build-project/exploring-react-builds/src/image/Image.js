import React from 'react';
import cat from './react-builds-cat.png';
import './Image.css';

console.log(cat);

function Image() {
    return (
        <div>
            <img src={cat} alt="Cat" />
            <div className="cat"></div>
        </div>
    )
}



export default Image;
