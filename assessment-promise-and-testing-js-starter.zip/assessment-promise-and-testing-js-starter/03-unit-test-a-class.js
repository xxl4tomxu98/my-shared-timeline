const chai = require('chai');
const spies = require('chai-spies');
chai.use(spies);
const expect = chai.expect;

/**
 * In this file, you will test the class Rounder and its methods. The outline of
 * the expected tests is provided for you in describe/it format.
 *
 * NOTE: Put your tests in this file, not in the file in the test directory!
 */

/* BEGIN_CLASS_ROUNDER */
class Rounder {
  constructor(number) {
    this.number = number;
  }

  roundDown() {
    return Math.floor(this.number);
  }

  roundUp() {
    return Math.ceil(this.number);
  }

  roundUpToNearest10() {
    let n = Math.ceil(this.number);
    n = n - n % 10;
    return n + 10;
  }
}
/* END_CLASS_ROUNDER */

/**
 * DO NOT CHANGE ANY CODE ABOVE THIS LINE.
 */

describe('Rounder class', () => {
  let myRounder;
  const num = 6.75;
  beforeEach( () => {
    myRounder = new Rounder(num);
  });

  context('roundDown() method', () => {
    it('returns a number rounded down to the nearest integer', () => {
      //expect.fail('Remove this expect.fail and replace it with your test');
      expect(myRounder.roundDown()).to.equal(6);
    });
  });

  context('roundUp() method', () => {
    it('returns a number rounded up to the nearest integer', () => {
      //expect.fail('Remove this expect.fail and replace it with your test');
      expect(myRounder.roundUp()).to.equal(7);
    });
  });

  context('roundUpToNearest10() method', () => {
    it('returns the closest multiple of 10 greater than the input', () => {
      //expect.fail('Remove this expect.fail and replace it with your test');
      expect(myRounder.roundUpToNearest10()).to.equal(10);
    });
  });
});
