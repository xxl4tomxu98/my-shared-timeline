
const { expect } = require('chai');
class Rounder {
  constructor(number) {
    this.number = number;
  }

  roundDown() {
    return null;
  }

  roundUp() {
    return null;
  }

  roundUpToNearest10() {
    return null;
  }
}
/* END_CLASS_ROUNDER */

/**
 * DO NOT CHANGE ANY CODE ABOVE THIS LINE.
 */

describe('Rounder class', () => {
  let myRounder;
  const num = 6.75;
  beforeEach( () => {
    myRounder = new Rounder(num);
  });

  context('roundDown() method detects bad output when it', () => {
    it('returns a number rounded down to the nearest integer', () => {
    let failed = false;
    try {
      
      //expect.fail('Remove this expect.fail and replace it with your test');
      expect(myRounder.roundDown()).to.equal(6);
    
    } catch (e) {
      if (e.actual !== undefined && e.expected !== undefined) {
        failed = true;
      }
    }
    if (!failed) {
      expect.fail('You test did not handle bad output');
    }
});
  });

  context('roundDown() method detects bad output when it', () => {
    it('returns a number rounded up to the nearest integer', () => {
    let failed = false;
    try {
      
      //expect.fail('Remove this expect.fail and replace it with your test');
      expect(myRounder.roundUp()).to.equal(7);
    
    } catch (e) {
      if (e.actual !== undefined && e.expected !== undefined) {
        failed = true;
      }
    }
    if (!failed) {
      expect.fail('You test did not handle bad output');
    }
});
  });

  context('roundUpToNearest10() method method detects bad output when it', () => {
    it('returns the closest multiple of 10 greater than the input', () => {
    let failed = false;
    try {
      
      //expect.fail('Remove this expect.fail and replace it with your test');
      expect(myRounder.roundUpToNearest10()).to.equal(10);
    
    } catch (e) {
      if (e.actual !== undefined && e.expected !== undefined) {
        failed = true;
      }
    }
    if (!failed) {
      expect.fail('You test did not handle bad output');
    }
});
  });
});



