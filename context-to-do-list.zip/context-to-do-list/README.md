# Context To-Do List
Completed as part of the App Academy curriculum. Implementation by Tom Xu and Juliet Shafto.

## Project Description
A simple to-do list application using React and local storage.

## Project Checklist
- [x] Project setup and context creation
- [x] Context provider component
- [x] Consumer component
- [x] Accessing context through contextType
