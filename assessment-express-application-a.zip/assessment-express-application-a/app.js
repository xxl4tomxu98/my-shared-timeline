/**
 * TODO: Create and configure your Express.js application in here.
 *       You must name the variable that contains your Express.js
 *       application "app" because that is what is exported at the
 *       bottom of the file.
 */
const express = require("express");
const cookieParser = require("cookie-parser");
const csrf = require("csurf");
const port = process.env.PORT || 8081;

const app = express();
app.set("view engine", "pug");
app.use(cookieParser());
app.use(express.urlencoded({extended: false}));
const csrfProtection = csrf({ cookie: true});
const { Entree, EntreeType } = require('./models');

const asyncHandler = (handler) => (req, res, next) => handler(req, res, next).catch(next);

app.get('/', asyncHandler(async (req, res) => {
  const entrees = await Entree.findAll({ include: EntreeType});
  res.render("entree-list", {title:"Entrees List", entrees});
}));

app.get('/entrees/new', csrfProtection, asyncHandler( async (req, res) =>{
  const entreeTypes = await EntreeType.findAll({order: ['name']});
  res.render('entree-add', {title: 'Add Entree', entreeTypes, csrfToken: req.csrfToken()});
}));




app.post('/entrees', csrfProtection, asyncHandler( async (req, res) =>{
  const {name, description, price, entreeTypeId } = req.body;
  const entree = Entree.build({name, description, price, entreeTypeId});
  await entree.save();
  res.redirect('/');
}));



app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})






























/* Do not change this export. The tests depend on it. */
try {
  exports.app = app;
} catch(e) {
  exports.app = null;
}
