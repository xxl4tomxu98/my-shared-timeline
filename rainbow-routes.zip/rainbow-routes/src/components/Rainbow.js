import React from 'react';
import { Route, Link, NavLink } from 'react-router-dom';
import Red from './Red.js';
import Blue from './Blue.js';
import Green from './Green.js';
import Violet from './Violet.js';




const Rainbow = () => (
    <div>
      <h1>Rainbow Router</h1>
      <NavLink exact to="/red" activeClassName="parent-active">Red</NavLink>
      <NavLink exact to="/blue" activeClassName="parent-active">Blue</NavLink>
      <NavLink to="/green" activeClassName="parent-active">Green</NavLink>
      <NavLink to="/violet" activeClassName="parent-active">Violet</NavLink>
      <div id='Rainbow'>
        <Route path="/" component={Rainbow} >
        <Route path="/red" component={Red} />
        <Route path="/blue" component={Blue} />
        <Route path="/green" component={Green} />
        <Route path="/violet" component={Violet} />
        </Route>
      </div>
    </div>
)

export default Rainbow;
