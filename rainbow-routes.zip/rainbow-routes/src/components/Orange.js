import React from 'react';
import { Route, Link, NavLink } from 'react-router-dom';

const Orange = () => (
    <div>
        <h3 className='orange'>Orange</h3>
    </div>
);

export default Orange;
