import React from 'react';

const Violet = () => (
    <div>
        <h2 className='violet'>Violet</h2>
    </div>
);

export default Violet;
