import React from 'react';

const Indigo = () => (
  <div>
    <h3 className="indigo">Indigo</h3>
  </div>
);

export default Indigo;
