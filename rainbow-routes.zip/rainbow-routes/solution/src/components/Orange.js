import React from 'react';

const Orange = () => (
  <div>
    <h3 className="orange">Orange</h3>
  </div>
);

export default Orange;
