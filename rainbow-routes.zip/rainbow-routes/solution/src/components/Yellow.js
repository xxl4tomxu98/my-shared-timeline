import React from 'react';

const Yellow = () => (
  <div>
    <h3 className="yellow">Yellow</h3>
  </div>
);

export default Yellow;
