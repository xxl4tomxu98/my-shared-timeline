import React from 'react';
import Calculator from './Calculator'

const App = () => (
  <div className="App">
    <h1><Calculator/></h1>
  </div>
);

export default App;
