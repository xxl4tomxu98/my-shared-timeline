const HumanPlayer =require('./HumanPlayer.js');
const Board = require('./Board.js');

class BattleshipGame {
  constructor(){
    //initiate board size and ship numbers
    this.myBoard = new Board(10, 10, 5);
    //initiate player input on square to hit
    this.player = new HumanPlayer(0,0);
    //initiate the random population of the board
    this.myBoard.populateGrid();
    this.play = this.play.bind(this);
  }


  play(){
    this.playTurn();
    this.displayStatus();
    if(this.myBoard.gameOver()){
      console.log("You hit all ships, game over!");
      return true;
    }

  }


  playTurn(){
    this.player.getMove(this.play);
    this.myBoard.attack(this.player.xcoord, this.player.ycoord);
  }

  displayStatus(){
    this.myBoard.display();
  }
}

module.exports=BattleshipGame;
