const BattleshipGame = require('./BattleshipGame.js');

const game = new BattleshipGame();
game.play();
