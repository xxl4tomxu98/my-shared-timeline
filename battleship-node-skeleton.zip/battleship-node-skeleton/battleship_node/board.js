const { ALPHABET } = require('./util');

class Board {
  constructor(rowSize, colSize, numShips) {
    this._rowSize = rowSize;
    this._colSize = colSize;
    this.populateGrid(numShips);
  }

  isGameOver() {
    return this.count() === 0;
  }

  count() {
    let numShipsLeft = 0;
    this._forEach((space) => {
      if (space === "s") numShipsLeft++;
    });
    return numShipsLeft;
  }

  populateGrid(numShips) {
    const grid = [];
    for (let i = 0; i < this._rowSize; i++) {
      grid.push(Array(this._colSize).fill(null));
    }

    let [row, col] = this._randomPos();
    while (numShips) {
      while (grid[row][col]) {
        [row, col] = this._randomPos();
      }
      grid[row][col] = "s";
      numShips--;
    }

    this.grid = grid;
  }

  isValidMove(pos) {
    const [row, col] = pos;
    if (
      row < 0
      || row >= this._rowSize
      || col < 0
      || col >= this._colSize
    ) return false;

    if (
      this.grid[row][col] === 'h'
      || this.grid[row][col] === 'x'
    ) return false;

    return true;
  }

  attack(pos) {
    const [row, col] = pos;
    const space = this.grid[row][col];
    if (space === 's') this.grid[row][col] = 'h';
    else if (space === null) this.grid[row][col] = 'x';
  }

  display() {
    let printStr = "   " + this.grid[0].map((_, col) => col).join(" ");
    printStr += '\n';
    printStr += "  " + "--".repeat(this._colSize) + "-";
    printStr += "\n";

    let rowStr = "|";

    const forEachCol = (space) => {
      if (space && space !== 's') rowStr += space;
      else rowStr += " ";
      rowStr += "|";
    };

    const afterEachRow = (_, row) => {
      printStr += ALPHABET[row] + " " + rowStr;
      printStr += "\n";
      printStr += "  " + "--".repeat(this._colSize) + "-";
      printStr += '\n'
      rowStr = "|";
    };

    this._forEach(forEachCol, afterEachRow);
    return printStr;
  }

  _forEach(colCb, rowCb) {
    // rowCb is optional
    for (let i = 0; i < this._rowSize; i++) {
      for (let j = 0; j < this._colSize; j++) {
        colCb(this.grid[i][j], [i, j]);
      }
      if (rowCb) rowCb(this.grid[i], i);
    }
  }

  _randomPos() {
    const row = Math.floor(Math.random() * this._rowSize);
    const col = Math.floor(Math.random() * this._colSize);
    return [row, col];
  }
}

module.exports = Board;