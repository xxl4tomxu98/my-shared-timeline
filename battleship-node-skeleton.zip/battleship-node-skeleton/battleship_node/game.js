const Board = require('./board');

class BattleshipGame {
  constructor(player1, rowSize, colSize, numShips) {
    this.player1 = player1;
    this.currentPlayer = player1;
    this.rowSize = rowSize;
    this.colSize = colSize;
    this.numShips = numShips;
    this.turn = 1;
    this.processMove = this.processMove.bind(this);
  }

  play() {
    console.log("Starting a new Battleship Game...");
    this.board = new Board(this.rowSize, this.colSize, this.numShips);
    this.playTurn();
  }

  playTurn() {
    this.displayStatus();
    this.getInput();
  }

  getInput() {
    this.currentPlayer.getMove(this.processMove);
  }

  processMove(pos) {
    if (this.isValidMove(pos)) {
      this.attack(pos);
      if (this.isGameOver()) {
        this.displayStatus();
        this.currentPlayer.processGameOver(true, this.turn);
      } else {
        this.turn++;
        this.playTurn();
      }
    } else {
      console.log('Please input a valid position.');
      this.currentPlayer.getMove(this.processMove);
    }
  }

  attack(pos) {
    this.board.attack(pos);
  }

  isGameOver() {
    return this.board.isGameOver();
  }

  isValidMove(pos) {
    return this.board.isValidMove(pos);
  }

  displayStatus() {
    console.log('\n*******************************')
    console.log("'s' means hit, 'x' means no-hit\n");
    console.log(this.board.display());
  }
}

module.exports = BattleshipGame;