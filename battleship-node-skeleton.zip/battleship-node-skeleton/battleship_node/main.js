const readline = require("readline");
const Board = require("./board");
const HumanPlayer = require("./humanPlayer");
const BattleshipGame = require("./game");

const rl = readline.createInterface(process.stdin, process.stdout);

const player1 = new HumanPlayer(rl);

const game = new BattleshipGame(player1, 1, 2, 1);
game.play();