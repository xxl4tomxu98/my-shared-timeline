class Board{
  constructor(numRows, numCols, numShips) {
    this.numRows = numRows;
    this.numCols = numCols;
    this.numShips = numShips;
    this.grid = [];
  }

  populateGrid(){
    //2-D array representing the board created with numShips
    //randomly located on squares of the board
    let grid = [];
    for(let i=0;i<this.numRows;i++){
      let column = [];
      for(let j=0;j<this.numCols;j++){
        column.push(' ');
      }
      grid.push(column);
    }


    //console.log(randonRow, randonCol);
    for(let k=0;k<this.numShips;k++){
      let randonRow = Math.floor(Math.random()*this.numRows);
      let randonCol = Math.floor(Math.random()*this.numCols);
      grid[randonRow][randonCol]="s";
    }
    //console.log(grid);
    this.grid = grid;
    return this.grid;
  }



  gameOver(){
    if(this.numShips===0){
      return true;
    }
    return false;
  }


  attack(xcoord, ycoord){
    if(this.grid[xcoord][ycoord]===' '){
      this.grid[xcoord][ycoord] ="x";
    } else if(this.grid[xcoord][ycoord]==="s"){
      this.grid[xcoord][ycoord] = "h";
      this.numShips -= 1;
    }
  }


  display(){
    let alpha ='abcdefghijklmnopqrstuvwxyz';
    let index = [];
    for(let r=0;r<this.numRows;r++){
      index.push(r);
      console.log(alpha[r] + '  ' + this.grid[r].join('|'));
    }
    console.log('   '+ index.join(' '));
  }
}
// let myBoard = new Board(5,5,3);
// myBoard.populateGrid();
// myBoard.display();

module.exports = Board;
