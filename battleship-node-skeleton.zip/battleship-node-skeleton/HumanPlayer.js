const readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


class HumanPlayer {
  constructor(x,y) {
    this.xcoord = x;
    this.ycoord = y;
  }

  getMove(processPlay){
  // rl.question is an asynchronous function!!
    rl.question("Which square? row, col:\n", answer => {
      console.log("So you want to hit " + answer);
      [this.xcoord, this.ycoord] = answer.split(',').map(Number);
      if(processPlay()){
        rl.close();
      }
    });
  }
}

module.exports = HumanPlayer;

// let player1 = new HumanPlayer();
// player1.getMove();
//  12345678910
//A|00000000000
//B|00000000000
//C|00000000000
//D|00000000000
//E|00000000000
//F|00000000000
//G|00000000000
//H|00000000000
//I|00000000000
//J|00000000000
