import React from 'react';
import DogBrowser from './DogBrowser';
function App() {
  return (
    <DogBrowser />
  );
}

export default App;
