import React from 'react';

import StopwatchManager from "./StopwatchManager";

function App() {
  return <StopwatchManager />;
}

export default App;
