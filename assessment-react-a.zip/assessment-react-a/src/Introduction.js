import React from 'react';


const Introduction = props =>
  <h1>
    Click a product link on the left.
  </h1>





export default Introduction;
