import Animal from './animal.js';

export class Cat extends Animal {

  meow() {
    console.log("meow meow meow")
  }
}

