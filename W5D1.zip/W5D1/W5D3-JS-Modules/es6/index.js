import { Dog } from './dog.js';
import { Cat } from './cat.js';
import { Family } from './family.js';


// const pancake = new Dog('pancake', 5);
// const cat = new Cat('frank', 10);

// window.Dog = Dog;
// window.Cat = Cat;
window.Family = Family;

