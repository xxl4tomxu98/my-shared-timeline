INSERT INTO customers(name, contact_email)
VALUES
('Riley Reeves', 'primis.in.faucibus@pellentesqueegetdictum.edu'),
('Jarrod Newman', 'turpis.Aliquam.adipiscing@auctor.ca');
