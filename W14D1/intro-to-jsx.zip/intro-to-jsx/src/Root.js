import React from 'react';
import App from './App';

const Root = () => {
  const hello = "hello";
  const sayHi = () => console.log('hi');
  const lecture = { topic: 'intro to jsx' };

  return (
    <>
      <App
        hello={hello}
        sayHi={sayHi}
        lecture={lecture}
      />
    </>
  );
};

export default Root;
