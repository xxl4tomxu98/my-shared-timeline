import React from 'react';

class AnimalImageClassComponent extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { animalType } = this.props;
    return (
      <img alt={animalType} src={`images/${animalType}.jpg`} />
    );
  }
};

export default AnimalImageClassComponent;
