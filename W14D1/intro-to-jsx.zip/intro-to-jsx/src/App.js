import React from 'react';
import './App.css';
import AnimalImageClassComponent from './AnimalImageClassComponent';

// props = {
//   hello: 'hello',
//   sayHi: () => console.log('hi'),
//   lecture: { topic: 'intro to jsx' },
// }


function App(props) {
  const animalTypes = ['dog', 'cat', 'koala'];
  // debugger
  console.log(props);
  return (
    <div className="app">
      <h1 onClick={props.sayHi}>{props.hello}</h1>
      <h1>{props.lecture.topic}</h1>
      {animalTypes.map((type) => {
        // console.log(animalTypes)
        return (
          <AnimalImageClassComponent animalType={type} key={type} />
        );
      })}
    </div>
  );
}

// const ArrowApp = (props) => (
//   <>
//     <h1>hello</h1>
//     <h1>hello</h1>
//     <h1>hello</h1>
//   </>
// );

export default App;
