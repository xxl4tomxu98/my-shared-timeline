import React from 'react';

// props = {
//   animalType: '?'
// }

const AnimalImageFunctionComponent = (props) => {
  const { animalType } = props;

  return (
    <img alt={animalType} src={`images/${animalType}.jpg`} />
  );
};

// const AnimalImageFunctionComponent = ({ animalType }) => {
//   return (
//     <img alt={animalType} src={`images/${animalType}.jpg`} />
//   );
// };

export default AnimalImageFunctionComponent;
