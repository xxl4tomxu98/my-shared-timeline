CREATE TABLE countries (
  id SERIAL PRIMARY KEY NOT NULL,
  name VARCHAR(100) NOT NULL,
  continent_name VARCHAR(20) NOT NULL
);
