INSERT INTO users(id, full_name, created_at)
VALUES
(DEFAULT, 'Zaphod Beeblebrox',	CURRENT_TIMESTAMP),
(DEFAULT, 'Blart Versenwald III',	CURRENT_TIMESTAMP);
