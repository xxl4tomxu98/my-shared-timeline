INSERT INTO countries (id, name, continent_name)
VALUES
(DEFAULT, 'Brazil',	'South America'),
(DEFAULT, 'China',	'Asia'),
(DEFAULT, 'USA',	'North America');
