INSERT INTO merchants (id, merchant_name, country_id, created_at, admin_id,  merchant_type_id)
VALUES
(DEFAULT, 'Zingo',	1,	CURRENT_TIMESTAMP,	1,	1),
(DEFAULT, 'Widgets International',	2,	CURRENT_TIMESTAMP,	2,	2),
(DEFAULT, 'Snglrify',	3,	CURRENT_TIMESTAMP,	1,	1),
(DEFAULT, 'Better Products 4 U',	3,	CURRENT_TIMESTAMP,	1,	2);
