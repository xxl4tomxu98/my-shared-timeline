INSERT INTO merchant_types (id, type)
Values
(DEFAULT, 'Retail'),
(DEFAULT, 'Wholesale');
