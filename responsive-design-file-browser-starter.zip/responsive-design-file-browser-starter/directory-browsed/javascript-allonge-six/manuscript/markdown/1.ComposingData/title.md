# Composing and Decomposing Data {#composing-data}

![Stacked Cups](images/stacked-cups.jpg)

> Recursion is the root of computation since it trades description for time.—Alan Perlis, [Epigrams in Programming](http://www.cs.yale.edu/homes/perlis-alan/quotes.html)