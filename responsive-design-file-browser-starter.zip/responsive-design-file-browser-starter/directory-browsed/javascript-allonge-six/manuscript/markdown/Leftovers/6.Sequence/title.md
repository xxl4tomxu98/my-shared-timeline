# Sequence {#processing}

![Saltspring Island Roasting Facility](images/saltspring/title.jpg)

Throughout the book, we've looked at how functions work, and more importantly, the many ways they can be decomposed into smaller parts and recombined in different ways. In this chapter. we will step back and look at a larger pattern, the use of `sequence` to control the processing of information.
