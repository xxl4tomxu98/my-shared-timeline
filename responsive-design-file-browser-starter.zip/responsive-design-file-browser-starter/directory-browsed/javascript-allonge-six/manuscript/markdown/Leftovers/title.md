# The Pause That Refreshes: Rebinding and References {#references}

![It is not enough that coffee taste beautiful. Everything about its creation and consumption should reflect coffee's beauty.](images/bezzera.jpg)