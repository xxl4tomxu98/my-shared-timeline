## About The Author

When he's not shipping JavaScript, Ruby, CoffeeScript and Java applications scaling out to millions of users, Reg "Raganwald" Braithwaite has authored [libraries][lib] for JavaScript, CoffeeScript, and Ruby programming such as Allong.es, Method Combinators, Katy, JQuery Combinators, YouAreDaChef, andand, and others.

[lib]: http://github.com/raganwald

He writes about programming on "[Raganwald][raganwald]," as well as general-purpose ruminations on "[Braythwayt Dot Com][braythwayt]".

[raganwald]: http://raganwald
[braythwayt]: http://braythwayt.com

### contact

Twitter: [@raganwald](https://twitter.com/raganwald)
Email: [reg@braythwayt.com](mailto:reg@braythwayt.com)

![Reg "Raganwald" Braithwaite ](images/reg2.jpg)