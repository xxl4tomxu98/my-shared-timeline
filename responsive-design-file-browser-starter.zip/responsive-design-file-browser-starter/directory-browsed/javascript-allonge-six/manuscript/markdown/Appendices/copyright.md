## Copyright Notice

The original words in this book are (c) 2012-2019, Reginald Braithwaite, and licensed under a [Creative Commons Attribution-ShareAlike 3.0 Unported License][license]. You are free:

* to Share—to copy, distribute and transmit the work
* to Remix—to adapt the work
* to make commercial use of the work

Provided you comply with the [license terms][license].

[license]: http://creativecommons.org/licenses/by-sa/3.0/deed.en_US "Creative Commons Attribution-ShareAlike 3.0 Unported License"
