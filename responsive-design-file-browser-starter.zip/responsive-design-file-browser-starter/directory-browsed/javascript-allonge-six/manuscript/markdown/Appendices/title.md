# The Golden Crema: Appendices and Afterwords

![La Marzocco](images/la_marzocco.jpg)
