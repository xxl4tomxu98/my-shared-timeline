## Reading JavaScript Allongé on Kindle

JavaScript Allongé has over 400 pages and many photographs. For this reason, the `.mobi` version of the book is too big to be sent to your Kindle via email, and that is the feature that LeanPub uses when you purchase the book.

![Send to Kindle](images/kindle.png)

So, if you wish to read JavaScript Allongé on your Kindle:

- Download it to your Windows or OS X device (a/k/a "PC" or "Macintosh").
- Use [Send to Kindle for PC](http://www.amazon.com/gp/sendtokindle/pc) or [Send to Kindle for Mac](http://www.amazon.com/gp/sendtokindle/mac) to send it to the Kindle.
- From time to time while editing, an uncompressed image sneaks into the manuscript. When this happens, the `.mobi` may exceed the 50MB limit for the Send to Kindle desktop application. If this happens, please attach your Kindle to your computer with a USB cable and synchronize directly.

Thank you!