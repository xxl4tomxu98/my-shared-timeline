## About The Sample PDF

This sample edition of the book includes just a portion of the complete book. Buying the book in progress entitles you to free updates, so [download it today][buy]! Besides, **there's really no risk at all**. If you read *JavaScript Allongé, The "six" edition* and it doesn't blow your mind, your money will be cheerfully refunded.

--Reginald "Raganwald" Braithwaite, Toronto, 2015

![No, this is not the author: But he has free coffee!](images/freecoffee.jpg)

[buy]: http://leanpub.com/javascriptallongesix