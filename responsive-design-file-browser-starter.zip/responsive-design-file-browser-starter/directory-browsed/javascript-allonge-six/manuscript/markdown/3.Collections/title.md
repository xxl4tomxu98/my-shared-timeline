# Served by the Pot: Collections {#collections}

![Some different sized and coloured coffee pots by Antti Nurmesniemi, perhaps his most known design.](images/pots.jpg)
