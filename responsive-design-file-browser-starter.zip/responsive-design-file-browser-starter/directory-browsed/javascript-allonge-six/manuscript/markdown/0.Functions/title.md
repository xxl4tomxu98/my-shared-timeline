# The first sip: Basic Functions {#functions}

![The perfect Café Allongé begins with the right beans, properly roasted. JavaScript Allongé begins with functions, properly dissected.](images/leaf-roaster.jpg)