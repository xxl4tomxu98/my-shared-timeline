# Life on the Plantation: Metaobjects {#metaobjects}

![Krups Machines](images/shadowbecomeswhite.jpg)[^shadowbecomeswhite]

[^shadowbecomeswhite]: [Krups Machines](http://www.flickr.com/photos/31383674@N00/10529091736) (c) 2010 Shadow Becomes White, [some rights reserved](http://creativecommons.org/licenses/by-nd/2.0/deed.en)

{pagebreak}
