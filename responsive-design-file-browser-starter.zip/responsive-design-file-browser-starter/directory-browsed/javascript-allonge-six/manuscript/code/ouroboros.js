var ouroboros = [];
ouroboros[0] = ouroboros;
  //=> [ [Circular] ]