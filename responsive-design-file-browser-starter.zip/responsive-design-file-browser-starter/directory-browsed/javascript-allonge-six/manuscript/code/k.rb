lambda { |x|
  lambda { |y| x }
}[1][2]
  #=> 1