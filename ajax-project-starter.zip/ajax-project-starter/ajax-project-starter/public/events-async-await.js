const startLoader = () => {
  document.querySelector(".loader").innerHTML = "Loading...";
};

const stopLoader = () => {
  document.querySelector(".loader").innerHTML = "";
};

const clearError = () => {
  document.querySelector(".error").innerHTML = "";
};

const handleResponse = response => {
  stopLoader();
  clearError();

  if (!response.ok) {
    throw response;
  }
  return response.json();
};

async function handleError(error) {
  if (error.json) {
    let errorJSON = await error.json();
    let errorMessage = document.querySelector(".error");
    errorMessage.innerHTML = `Error occured: ${errorJSON.message}`;
  } else {
    console.error(error);
    alert("Something went wrong. Please try again!");
  }
};

async function fetchImage () {
  startLoader();
  try{
    const img = await fetch("http://localhost:3000/kitten/image");
    const data = await handleResponse(img);
    document.querySelector(".cat-pic").src = data.src;
    document.querySelector(".score").innerHTML = data.score;
    document.querySelector(".comments").innerHTML = "";
  } catch(e) {
    handleError(e);
  }
}

async function upVote(){
  try{
    const vote = await fetch("http://localhost:3000/kitten/upvote", { method: "PATCH" });
    const handledVote = await handleResponse(vote);
    updateImageScore(handledVote);
  } catch(e){
    handleError(e);
  }
}

async function downVote(){
  try{
    const vote = await fetch("http://localhost:3000/kitten/downvote", { method: "PATCH" });
    const handledVote = await handleResponse(vote);
    updateImageScore(handledVote);
  } catch(e){
    handleError(e);
  }
}

const updateImageScore = data => {
  const { score } = data;
  document.querySelector(".score").innerHTML = score;
};

window.addEventListener("DOMContentLoaded", fetchImage);

document.querySelector("#new-pic").addEventListener("click", fetchImage);

document.querySelector("#upvote").addEventListener("click", upVote);

document.querySelector("#downvote").addEventListener("click", downVote);

const receiveComments = data => {
  const comments = document.querySelector(".comments");
  comments.innerHTML = "";
  data.comments.forEach((comment, i) => {
    const newCommentContainer = document.createElement("div");
    newCommentContainer.className = "comment-container";

    const newComment = document.createElement("p");
    newComment.appendChild(document.createTextNode(comment));

    const deleteButton = document.createElement("button");
    deleteButton.appendChild(document.createTextNode("Delete"));
    deleteButton.className = "delete-button";
    deleteButton.setAttribute("id", i);

    newCommentContainer.appendChild(newComment);
    newCommentContainer.appendChild(deleteButton);
    comments.appendChild(newCommentContainer);
  });
};

const commentForm = document.querySelector(".comment-form");

commentForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(commentForm);
  const comment = formData.get("user-comment");
  try{
    const newComment = await fetch("http://localhost:3000/kitten/comments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ comment:comment })
    });
    const data = await handleResponse(newComment);
    commentForm.reset();
    receiveComments(data);
  } catch(e){
    handleError(e);
  }
});

document.querySelector(".comments").addEventListener("click", async (event) => {
  if (event.target.tagName != "BUTTON") return;
  try{
    const index = await fetch(`kitten/comments/${event.target.id}`, { method: "DELETE" });
    const data = await handleResponse(index);
    receiveComments(data);
  } catch(e) {
    handleError(e);
  }
});
