'use strict';
module.exports = (sequelize, DataTypes) => {
  const Airplane = sequelize.define('Airplane', {
    model: DataTypes.STRING,
    capacity: DataTypes.INTEGER
  }, {});
  Airplane.associate = function(models) {
    Airplane.hasMany(models.Flight, { foreignKey: 'airplaneId' });
  };
  return Airplane;
};