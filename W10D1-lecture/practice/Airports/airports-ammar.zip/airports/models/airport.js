'use strict';
module.exports = (sequelize, DataTypes) => {
  const Airport = sequelize.define('Airport', {
    airportCode: DataTypes.STRING,
    airportName: DataTypes.STRING
  }, {});
  Airport.associate = function(models) {
    Airport.hasMany(models.Flight, { as: 'DepartingFlight', foreignKey: 'departureAirportId' });
    Airport.hasMany(models.Flight, { as: 'ArrivingFlight',foreignKey: 'arrivalAirportId' });
  };
  return Airport;
};