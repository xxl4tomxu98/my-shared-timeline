'use strict';
module.exports = (sequelize, DataTypes) => {
  const Flight = sequelize.define('Flight', {
    date: DataTypes.DATE,
    time: DataTypes.TIME,
    departureAirportId: DataTypes.INTEGER,
    arrivalAirportId: DataTypes.INTEGER,
    status: DataTypes.STRING,
    departureGate: DataTypes.STRING,
    airplaneId: DataTypes.INTEGER
  }, {});
  Flight.associate = function(models) {
    Flight.belongsTo(models.Airport, { foreignKey: 'departureAirportId' });
    Flight.belongsTo(models.Airport, {foreignKey: 'arrivalAirportId' });
    Flight.belongsTo(models.Airplane, { foreignKey: 'airplaneId' });
  };
  return Flight;
};