CREATE TABLE Airports(
    id SERIAL PRIMARY KEY,
    airportCode VARCHAR(5) NOT NULL,
    airportName VARCHAR(50) NOT NULL
);

INSERT INTO Airports (id, airportCode, airportName)
VALUES
(1, 'YYC', 'Calgary'),
(2, 'YYZ', 'Toronto'),
(3, 'YVR', 'Vancouver'),
(4, 'YUL', 'Montreal');


CREATE TABLE Airplanes
(
    id SERIAL PRIMARY KEY,
    model VARCHAR(20) NOT NULL,
    capacity INTEGER NOT NULL
);

INSERT INTO Airplanes (id, model, capacity)
VALUES
(1, '747', 500),
(2, '737', 100),
(3, 'Cessna 172', 4);

CREATE TABLE Flights
(
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    time TIME NOT NULL,
    departureAirportId INTEGER NOT NULL,
    arrivalAirportId INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL,
    departureGate VARCHAR(10) NOT NULL,
    airplaneId INTEGER NOT NULL,
    FOREIGN KEY (departureAirportId) REFERENCES Airports(id),
    FOREIGN KEY (arrivalAirportId) REFERENCES Airports(id),
    FOREIGN KEY (airplaneId) REFERENCES Airplanes(id)
    
);

INSERT INTO Flights (id, date, time, departureAirportId, arrivalAirportId, status, departureGate, airplaneId)
VALUES 
(1,'2020-03-01', '12:40', 1, 2, 'ON-TIME', 'D34', 1),
(2,'2020-04-01', '1:30', 4, 2, 'ON-TIME', 'D34', 1),
(3,'2020-05-01', '2:25', 4, 3, 'ON-TIME', 'D34', 1),
(4,'2020-06-01', '3:30', 3, 2, 'ON-TIME', 'D34', 2),
(5,'2020-07-01', '12:40', 2, 1, 'ON-TIME', 'D34',3),
(6,'2020-08-01', '2:14', 4, 3, 'ON-TIME', 'D34', 1);

SELECT * FROM flights
where date < '2020-07-01';

SELECT * FROM airports
JOIN flights ON (flights.departureAirportId = airports.id)
WHERE date < '2020-07-01';

SELECT *
FROM airplanes
    JOIN flights ON (flights.airplaneId = airplanes.id)
    JOIN airports on (flights.departureAirportId = airports.id)
WHERE airports.airportCode = 'YYC';