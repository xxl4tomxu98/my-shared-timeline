const { Airport, Flight, Airplane, Sequelize } = require('./models');
// const { where } = require('sequelize/types');
const Op = Sequelize.Op;

async function findFlightsBeforeDate(date){
    const finding = await Flight.findAll({
        where: {
            date: {
                [Op.lt]: date
            }
        }
    });
    console.log(finding);
    return finding;
}

async function findAirportBeforeDepartingDate(date){
    const finding = await Airport.findAll(
        {
            include: {
                model: Flight, 
                as: 'DepartingFlight', 
                where: {
                    date: { [Op.lt]: date }
                }
            }        
        }
    );
    console.log(finding)
    return finding;
    
}
async function findModelsFromAirport(code){
    const finding = await Airplane.findAll(
        {
            include:[{
                model:Flight,
                include:[{
                    model:Airport,
                    where:{airportCode: code}
                }], 
                required: true
            }]
        }
    )
    console.log(finding);
    return finding;
}
// findFlightsBeforeDate('2020-07-01');
findAirportBeforeDepartingDate('2020-07-01');
// findModelsFromAirport('YYC')