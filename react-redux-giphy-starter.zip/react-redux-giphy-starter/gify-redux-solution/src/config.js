export const apiKey = process.env.REACT_APP_GIPHY_API_KEY;
