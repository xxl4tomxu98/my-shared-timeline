/***********************************************************************
Write a recursive function called `sum` that takes an array of integers
and returns the value of all the integers added together. Your array may
include a mix of positive and negative integers!
Examples:
sum([1, 2, 3]); // => 6
sum([0, 1, -3]); // => -2
sum([1, 2, 3, 4, 5]); //=> 15
***********************************************************************/

// Your code here

function sum(array){
  if(array.length===1){
    return array[0];
  } else {
    return array[0] + sum(array.slice(1));
  }
}




/**************DO NOT MODIFY ANYTHING UNDER THIS LINE*****************/
try {
    module.exports = sum;
} catch {
    module.exports = null;
}
