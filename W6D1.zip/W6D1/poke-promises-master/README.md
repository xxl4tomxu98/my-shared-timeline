# Poke Promises :)

We're going to use the [pokeAPI](https://pokeapi.co/) to practice promises. 
