
// function declaration syntax


// sayGoodbye()

// function sayGoodbye() {
//   console.log('goodbye');
// }


// function expression syntax


// const sayGoodbye = function() {
//   console.log('goodbye');
// };


// sayGoodbye()

// const otherSayGoodbye = sayGoodbye;

// otherSayGoodbye()



// function declaration vs function expression
// - function declarations load before any code is executed
// - fucntion expressions load when line of code is reached





// ------------- MUTABILITY --------------------------


// immutable vs mutable
//  - immutable: cannot be changed (strings, numbers, booleans)
//  - mutable: can be changed (arrays, objects)


// let array = [1,2,3,4];

// array[0] = 'banana';

// array = ['hello'];

// console.log(array);

// array = array.concat([5,6,7]);

// console.log(array);


// ------------- PUSH/POP/SHIFT/UNSHIFT --------------------------



// let names = ["jesse", "alissa", "julie", "tom", "corina"];

// names.push('pancake');

// names.pop();

// names.shift();

// names.unshift('bob', 'pancake')

// let removedNames = names.splice(1, 0, 'pancake', 'bob');

// console.log(removedNames);

// let removedEl = names.pop();

// names.unshift(removedEl);



// let removedEl = names.pop();
// console.log(names.pop());

// console.log(removedEl);
// console.log(removedEl);

// console.log(names.pop());
// console.log(names.pop());


// let names = ["jesse", "alissa", "julie", "tom", "corina"];
// let newArr = [];

// for (let index = 0; index < 5; index++) {
//   let removedEl = names.pop();
//   newArr.push(removedEl);
//   // newArr = newArr.concat(removedEl);
// }

// console.log(newArr);


// ------------- NESTED LOOPS --------------------------


// for (let i = 0; i < 3; i++) {
//   console.log(i);

//   for (let j = 0; j < 4; j++) {
//     console.log('      ' + j);
//   }
// }

// let i = 0;
// while (i < 3) {
//   console.log(i);
//   i++;
//   let j = 0;
//   while (j < 4) {
//     console.log('      ' + j);
//     j++;
//   }
// }



// let nums = ["first", "second", "third"];

// for (let i = 0; i < nums.length; i++) {
//   let el1 = nums[i];

//   for (let j = i+1; j < nums.length; j++) {
//     let el2 = nums[j];
//     let pair = [el1, el2];

//     console.log(pair);
//   }
// }



// let grid = [
//   [1, 2, 3, 4],
//   [5, 6, 7, 8, 9],
//   [10, 11, 12]
// ]

// console.log(grid);

// for (let i = 0; i < grid.length; i++) {

//   for (let j = 0; j < grid[i].length; j++) {
    
//     let el = grid[i][j]
//     console.log(el);
//   }
// }
