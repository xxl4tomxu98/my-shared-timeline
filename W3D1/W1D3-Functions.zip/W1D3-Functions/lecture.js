// ---------------------------VIDEO 1------------------------------------------

// function declaration syntax 

function sayHello() {
  console.log('hello');
}

console.log(sayHello)
sayHello();


// function expression syntax 

const sayHello = function() {
  console.log(sayHello);
}

console.log(sayHello)
sayHello();


// assigning named func to variable

function sayGoodbye() {
  console.log('bye');
}

console.log(sayGoodbye);

const sayBye = sayGoodbye;

console.log(sayBye);

sayBye();



// function declaration vs function expression
// - function declarations load before any code is executed
// - function expressions load when line of code is reached


printName('alissa'); // this will work 

otherPrintName('alissa'); // this will not work 

function printName(name) {
  console.log(name);
}

const otherPrintName = function(name) {
  console.log(name);
}



// first class objects
//   - something you can store inside a variable
//   - treat func as "normal" value stored in variable
//   - variable's name is func's name

let myString = 'hello';
let myArray = ['hello'];
let myFunc = function () {
  console.log('hello')
}

console.log(myString); // hello
console.log(myArray); // ['hello']
console.log(myFunc); // [Function: myFunc]


// ---------------------------VIDEO 2------------------------------------------

// immutable vs mutable data
//   - mutable: can be changed(arrays, obj)
//   - immutable: cannot be changed(num, str, boolean)


let string = 'hello';
string.toUpperCase();
console.log(string); // hello

string = string.toUpperCase();
console.log(string); // HELLO


// arrays are mutable
//   - some array methods mutate
//   - some array methods do not mutate


let array = ['one', 'two', 'three'];

array[0] = 'zero';

console.log(array);

array.concat('four');

console.log(array);

array = array.concat(['four', 'five']);

console.log(array);


// Array#splice
//   - accepts two or more arguments:
//     * first is target index
//     * second is number of elements to remove
//     * additional args are els to insert
//   - returns new arr containing removed els
//   - removes els from original array


// removing with splice


let names = ["jesse", "alissa", "julie", "tom", "corina"];

let removedNames = names.splice(1, 2);
console.log(names);
console.log(removedNames);


// inserting with splice


let nums = ["one", "two", "four"];

let removed = nums.splice(2, 0, 'three');
console.log(nums);
console.log(removed);



// removing and inserting 


let names = ["jesse", "alissa", "julie", "tom", "corina"];
let removedNames = names.splice(1, 1, 'bob', 'joe');
console.log(names);
console.log(removedNames);


// ---------------------------VIDEO 3------------------------------------------


// mutating array methods 

let people = ['bob', 'joe', 'sally'];

console.log(people.push('alissa', 'julie')); 
console.log(people); 

console.log(people.pop());
console.log(people);

console.log(people.shift());
console.log(people);

console.log(people.unshift('tom', 'corina'));
console.log(people);



// find users whose first name starts with an 'b'

let people = ['bob', 'joe', 'sally', 'brenda', 'bruce'];
let filteredPeople = []

for (let i = 0 ; i < people.length; i++) {
  let person = people[i];
  if (person[0] === 'b' ) {
    // filteredPeople.concat(person); // non mutating
    // filteredPeople = filteredPeople.concat(person)
    filteredPeople.push(person); // mutating
  }
}


// reversing an array 

let array = [1,2,3,4,5,6];
let reversedArray = [];

for (let i = 0; i < array.length; i++) {
  let el = array[i];
  reversedArray.push(el);
}

console.log(reversedArray);

// ---------------------------VIDEO 4------------------------------------------


// nested loops

for (let i = 0; i <= 2; i++) {
  // console.log(i);

  for (let j = 0; j <= 4; j++) {
    // console.log('     ' + j);
    console.log(i, j);
  }
}


// nested while loops

let i = 0

while (i < 5) {
  let j = 0;
  i++
  console.log(i);
  while (j < 5) {
    console.log('     ' + j);
    j++
  }
}


// ---------------------------VIDEO 5------------------------------------------


// nested loops - all possible combinations

let array = ['first', 'second', 'third'];

for (let i = 0; i < array.length; i++) {
  let el1 = array[i];
  for (let j = 0; j < array.length; j++) {
    let el2 = array[j];

    console.log(el1, el2);
  }
}


// ---------------------------VIDEO 6------------------------------------------

// nested loops - unique pairs

for (let i = 0; i < array.length; i++) {
  let el1 = array[i];
  for (let j = i + 1; j < array.length; j++) {
    let el2 = array[j];

    console.log(el1, el2);
  }
}


// func returns false if array contains duplicate values

function isUnique(array) {
  for (let i = 0; i < array.length; i++) {
    let el1 = array[i];

    for (let j = i + 1; j < array.length; j++) {
      let el2 = array[j];

      if (el1 === el2) {
        return false;
      }
    }
  }
  return true;
}



// nested loops for multidimensional arrays


let grid = [
  [1, 2, 3, 4],
  [5, 6, 7, 8],
  [9, 10, 11, 12]
]


for (let row = 0; row < grid.length; row++) {

  for (let col = 0; col < grid[row].length; col++) {

    let el = grid[row][col];
    console.log(el)
  }
}