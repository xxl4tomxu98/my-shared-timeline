# Function Expressions


funcs as first-class objects
- treat func as "normal" value stored in variable
- variable's name is func's name


function declaration syntax
`function myFunctionName(arg1, arg2) {}`

function expression syntax
`let myFunctionName = function(arg1, arg2) {}`

anonymous function
`function(arg) {}`



# Two Dimensional Arrays 


two-dimensional arrays
- arrays contianing other arrays
- index at `[row][col]`
- iterate through using loop within a loop


when to use 2d array
- representing a "grid"
- tic tac toe, chess, sudoku, excel



# Mutability


overview
- mutable: can be changed
  * arrays, objects
- immutable: cannot be changed
  * number, string, boolean


arrays are mutable
- can assign new ele to index of array
- not every array method is mutable (`slice`)


strings are immutable
- cannot assign a new char to index of a string
- no methods modify existing string, they return new string


mutating methods 
- array: pop, shift, push

non-mutating methods
- array: concat


# Array#splice


notation
- `#` denotes methods 
- `Array#splice` => `arr.splice()`


overview
- mutates array its called on (modifies existing)
- used to remove or insert elements into the array


using splice to remove
- accepts two arguments:
  * first is target index
  * second is number of elements to remove
- returns new arr containing removed els
- removes els from original array

```js
let colors = ["red", "yellow", "blue", "green", "orange", "brown", "gray"];
let returnVal = colors.splice(2, 3);
console.log(colors); // [ 'red', 'yellow', 'brown', 'gray' ]
console.log(returnVal); // [ 'blue', 'green', 'orange' ]
```

using splice to insert
- pass additional args representing values to insert 

```js
let colors = ["red", "yellow", "blue"];
let returnVal = colors.splice(1, 0, "RebeccaPurple", "CornflowerBlue");
console.log(colors); // [ 'red', 'RebeccaPurple', 'CornflowerBlue', 'yellow', 'blue' ]
console.log(returnVal); // []
```




# Array methods


Array#push
- adds one or more els to end of array
- returns the new length 
- mutates array


Array#pop
- removes el from end of array
- returns removed el 
- mutates array


Array#unshift
- adds el to front of array
- returns the new length of array
- mutates array 


Array#shift
- removes el from front of array
- returns removed array
- mutates array


# Nested loops


overview
- useful for iterating through nested arrays
- usefulf or comparing values in array 
- loop through entire inner loop for each iteration of outer loop


total number of iterations
- number of inner iterations * number of outer iterations